// Variables

var str = "Hello, playground"
str = "Hello, world!"

var number = 10
number = 20

// Constants

let language = "Swift"

// Naming Conventions

/*
 Rule #1: Spaces not allowed
 let programming language = "Objective-C"
 */

/*
 Rule #2: Use camelCase
 let programming language = Objective-C // Wrong!
 */

let programmingLanguage = "Objective-C"
let favoriteProgrammingLanguage = "Swift"

var 😺 = "cat"
😺
